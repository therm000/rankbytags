
from PageRank import PageRank

nodes = ['A', 'B', 'C', 'D']
edges = [('A', 'B'),('B', 'D'),('D', 'C'),('C', 'A')]
# use C++
pagerank = PageRank(nodes, edges)
for node, rank in pagerank.ranking():
    print str((node,rank))

# use python
pagerank = PageRank(nodes, edges, False)
for node, rank in pagerank.ranking():
    print str((node,rank))

